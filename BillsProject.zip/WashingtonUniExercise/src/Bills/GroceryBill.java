package Bills;

import java.util.ArrayList;

public class GroceryBill {
	private ArrayList<Item> listOfItems = new ArrayList<Item>();

	public GroceryBill(Employee clerk) {
	}

	public void add(Item i) {
		listOfItems.add(i);
	}

	public double getTotal() {
		double total = 0;
		for (Item i : listOfItems) {
			total += i.getPrice();
		}
		return total;
	}

	public void printReceipt() {
		if (listOfItems.size() != 0) {
			for (Item i : listOfItems) {
				System.out.println(i.getName() + "   " + i.getPrice());
			}
			System.out.println();
		}
	}

	public int listSize() {
		return listOfItems.size();
	}

	public static void main(String[] args) {

	}

}
