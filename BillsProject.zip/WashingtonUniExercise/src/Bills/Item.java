package Bills;

public class Item {
	private String name;
	private double price;

	public Item(String name) {
		this.name = name;
		price = 0;
	}

	public double getPrice() {
		if (name.equals("Hamburger")) {
			price = 3.50;

		} else if (name.equals("Cheeseburger")) {
			price = 4.15;

		} else if (name.equals("Double Cheeseburger")) {
			price = 6.00;

		} else if (name.equals("Coke")) {
			price = 1.00;

		} else if (name.equals("Milkshake")) {
			price = 5.00;

		}
		return price;
	}

	public double getDiscount() {
		if (name.equals("Hamburger")) {
			price = 3.00;

		} else if (name.equals("Cheeseburger")) {
			price = 3.65;

		} else if (name.equals("Double Cheeseburger")) {
			price = 5.50;

		} else if (name.equals("Coke")) {
			price = 0.50;

		} else if (name.equals("Milkshake")) {
			price = 4.50;

		}
		return price;
	}

	public String getName() {
		return name;
	}

	public static void main(String[] args) {

	}

}
