package Bills;

public class DiscountBill extends GroceryBill {

	private boolean shouldGetDiscount;

	public DiscountBill(Employee clerk, Boolean shouldGetDiscount) {
		super(clerk);
		this.shouldGetDiscount = shouldGetDiscount;
	}

	public void add(Item i) {
		super.add(i);
	}

	public int getDiscountCount() {
		int count = 0;

		if (shouldGetDiscount == true) {
			count = super.listSize();
		} else {
			count = 0;
		}
		return count;

	}

	public double getDiscountAmount() {

		 if ( shouldGetDiscount == true) {
		return 0.50 * getDiscountCount();
		 }
		 else {
		 return 0 ;
		 }
	}

	public double getDiscountPercentage() {
		double originalPrice = this.getTotal();
		double discountedPrice = getDiscountedPrice();

		double percentage = discountedPrice / originalPrice;

		return 100 - (percentage * 100);

	}

	public double getDiscountedPrice() {
		return this.getTotal() - getDiscountAmount();
	}

	public static void main(String[] args) {

	}

}
