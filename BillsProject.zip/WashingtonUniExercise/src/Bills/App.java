package Bills;

import java.util.Scanner;

public class App {
	private static Scanner input = new Scanner(System.in);
	private static Employee employeeP = new Employee("Phetrus");
	private static GroceryBill bill = new GroceryBill(employeeP);
	private static DiscountBill discountBill = new DiscountBill(employeeP, true);

	public void till() {
		int index = 0;

		while (index == 0) {
			System.out.println("Enter what you'd like to eat or enter stop to finish purchase?: ");
			String itemBought = input.nextLine();
			Item item;
			if (itemBought.equals("Stop") != true) {
				item = new Item(itemBought);
				bill.add(item);
				discountBill.add(item);
			} else if (itemBought.equals("Stop")) {

				index = 1;
			}

		}
	}

	public void discount() {

		System.out.println();
		System.out.println("Would you like a discount?: ");
		String userInput = input.nextLine();
		if (userInput.equals("No")) {
			System.out.println();
			System.out.println("RECEIPT FOR YOUR PURCHASE");
			System.out.println();
			bill.printReceipt();
			System.out.println("The total is: " + bill.getTotal());

		} else if (userInput.equals("Yes")) {
			
			System.out.println("Enter your unique discount code: ");
			String uniqueCode = input.nextLine();
			if ( uniqueCode.equals("Five Guys")) {

			System.out.println();
			System.out.println();

			System.out.println("RECEIPT FOR YOUR PURCHASE");
			System.out.println();
			bill.printReceipt();
			System.out.println("The total is: " + bill.getTotal());
			System.out.println("Price after discount is: " + discountBill.getDiscountedPrice());
			System.out.println("The discounted amount is: " + discountBill.getDiscountAmount());
			System.out.println("Percentage taken off original price: " + discountBill.getDiscountPercentage() + " %");

		}
			else {
				System.out.println();
				System.out.println("Discount code not recognized");
				System.out.println();
				System.out.println("RECEIPT FOR YOUR PURCHASE");
				System.out.println();
				bill.printReceipt();
				System.out.println("The total is: " + bill.getTotal());
			}
		}

	}

	public static void main(String[] args) {
		System.out.println(
				"Welcome to five guys, our menu consists of our famous Double Cheeseburger, Hamburger, Cheesebuurger, Milkshake and the good original American coke.");
		System.out.println();
		App app = new App();
		app.till();
		app.discount();

	}
}
